package application;

import java.util.ArrayList;
import java.util.List;

//Setters and Getters class for attributes of Questions

public class Question {
    private long id;
    private String text;
    private final List<Answer> answers;
    private boolean resolved;
    private String author;
    
    public Question(long id, String text, String author) {
        this.id = id;
        this.text = text;
        this.answers = new ArrayList<>();
        this.resolved = false;
        this.author = author;
    }

    public long getId() {
        return id;
    }

    public String getText() {
        return text;
    }
    
    public String getAuthot() {
    	return author;
    }

    public void setText(String newText) {
        this.text = newText;
    }

    public List<Answer> getAnswers() {
        return answers;
    }

    public boolean isResolved() {
        return resolved;
    }

    public void setResolved(boolean resolved) {
        this.resolved = resolved;
    }
}
