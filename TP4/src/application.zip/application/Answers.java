package application;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class Answers {
    private final Connection connection;
    private final ObservableList<Answer> allAnswers = FXCollections.observableArrayList();

    public Answers(Connection connection) { //Constructor!
        this.connection = connection;
    }

    public void createTable() throws SQLException { //Creates table
        try (Statement st = connection.createStatement()) {
            st.executeUpdate("""
                CREATE TABLE IF NOT EXISTS answer (
                  id IDENTITY PRIMARY KEY,
                  question_id BIGINT NOT NULL,
                  text VARCHAR(255) NOT NULL,
                  author VARCHAR(255) NOT NULL,
                  likes INT DEFAULT 0,
                  FOREIGN KEY (question_id) REFERENCES question(id) ON DELETE CASCADE
                )
            """);
        }
    }

    public void loadAllFromDB() throws SQLException { //Getter that fetches existing data
        allAnswers.clear();
        try (Statement st = connection.createStatement();
             ResultSet rs = st.executeQuery("SELECT id, question_id, text, author, likes FROM answer")) {
            while (rs.next()) {
                long id = rs.getLong("id");
                long qId = rs.getLong("question_id");
                String txt = rs.getString("text");
                int likes = rs.getInt("likes");
                String author = rs.getString("author");
                allAnswers.add(new Answer(id, qId, txt, likes, author));
            }
        }
    }

    public void linkAnswersToQuestions(ObservableList<Question> questions) { //Links answers and questions together
        for (Answer ans : allAnswers) {
            for (Question q : questions) {
                if (q.getId() == ans.getQuestionId()) {
                    q.getAnswers().add(ans);
                    break;
                }
            }
        }
    }

    public void createAnswer(Question question, String text, User user) { //Creates new answers for a question
        try {
            long newId = insertAnswerDB(question.getId(), text, user.getUserName());
            Answer ans = new Answer(newId, question.getId(), text, 0, user.getUserName());
            allAnswers.add(ans);
            question.getAnswers().add(ans);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateAnswer(Answer ans, String newText) { //Updates the selected answer
        try {
            String sql = "UPDATE answer SET text=? WHERE id=?";
            try (PreparedStatement ps = connection.prepareStatement(sql)) {
                ps.setString(1, newText);
                ps.setLong(2, ans.getId());
                ps.executeUpdate();
            }
            ans.setText(newText);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteAnswer(Answer ans, Question q) { //Delete an answer
        try {
            String sql = "DELETE FROM answer WHERE id=?";
            try (PreparedStatement ps = connection.prepareStatement(sql)) {
                ps.setLong(1, ans.getId());
                ps.executeUpdate();
            }
            allAnswers.remove(ans);
            q.getAnswers().remove(ans);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Answer> getAnswersForQuestion(long questionId) { //Fteches answers for a question
        List<Answer> subset = new ArrayList<>();
        for (Answer ans : allAnswers) {
            if (ans.getQuestionId() == questionId) {
                subset.add(ans);
            }
        }
        return subset;
    }

    //Unused
    /*
    public List<Answer> search(String partial) {
        String lower = partial.toLowerCase();
        List<Answer> subset = new ArrayList<>();
        for (Answer ans : allAnswers) {
            if (ans.getText().toLowerCase().contains(lower)) {
                subset.add(ans);
            }
        }
        return subset;
    }
*/
    public void likeAnswer(Answer ans) { //Incrementer for likes
        try {
            String sql = "UPDATE answer SET likes = likes + 1 WHERE id = ?";
            try (PreparedStatement ps = connection.prepareStatement(sql)) {
                ps.setLong(1, ans.getId());
                ps.executeUpdate();
            }
            ans.incrementLikes();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private long insertAnswerDB(long questionId, String text, String author) throws SQLException { //Inserts answer to the database
        String sql = "INSERT INTO answer (question_id, text, author) VALUES (?, ?, ?)";
        try (PreparedStatement ps = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setLong(1, questionId);
            ps.setString(2, text);
            ps.setString(3, author);
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    return rs.getLong(1);
                }
            }
        }
        throw new SQLException("Failed to insert answer.");
    }
}
