package application;

//Setters and Getters class for attributes of answers

public class Answer {
    private long id;
    private long questionId;
    private String text;
    private int likes;
    private String author;

    public Answer(long id, long questionId, String text, int likes, String author) {
        this.id = id;
        this.questionId = questionId;
        this.text = text;
        this.likes = likes;
        this.author = author;
    }

    public Answer(long id, long questionId, String text, String author) {
        this(id, questionId, text, 0, author);
    }

    public long getId() {
        return id;
    }

    public long getQuestionId() {
        return questionId;
    }

    public String getText() {
        return text;
    }
    
    public String getAuthor() {
    	return author;	
    }

    public void setText(String newText) {
        this.text = newText;
    }

    public int getLikes() {
        return likes;
    }

    public void setLikes(int likes) {
        this.likes = likes;
    }

    public void incrementLikes() {
        this.likes++;
    }

    @Override
    public String toString() {
        return text + " [Likes: " + likes + "]";
    }
}
