package application;

import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.util.List;

public class AnswersWindow extends Stage {

    private final Question question;
    private final Answers answersManager;

    private ListView<Answer> answersListView;
    private TextField answerInput;
    private Label messageLabel;

    public AnswersWindow(Question question, Answers answersManager, User user) { //Opens the answers window for the selected question/Constructor!
        this.question = question;
        this.answersManager = answersManager;

        setTitle("Answers for: " + question.getText());

        
        answersListView = new ListView<>();
        answerInput = new TextField();
        answerInput.setPromptText("Enter your answer...");
        
       
        if (question.isResolved()) {
            answerInput.setDisable(true);
        }

        
        loadAnswers();

       
        Button addBtn = new Button("Add Answer");
        addBtn.setDisable(question.isResolved()); 
        addBtn.setOnAction(e -> addAnswer(user));

        Button updateBtn = new Button("Update Answer");
        updateBtn.setOnAction(e -> updateAnswer(user));

        Button deleteBtn = new Button("Delete Answer");
        deleteBtn.setOnAction(e -> deleteAnswer(user));

        Button likeBtn = new Button("Like Answer");
        likeBtn.setOnAction(e -> likeAnswer());

        
        messageLabel = new Label();

        VBox layout = new VBox(10);
        layout.setAlignment(Pos.CENTER);
        layout.setPadding(new Insets(15));

        layout.getChildren().addAll(
            new Label("Answers for question: \"" + question.getText() + "\""),
            answersListView,
            answerInput,
            new HBox(10, addBtn, updateBtn, deleteBtn, likeBtn),
            messageLabel
        );

        Scene scene = new Scene(layout, 600, 400);
        setScene(scene);
    }

    private void loadAnswers() { //Fetches all the answers for selected questions
        List<Answer> answerList = answersManager.getAnswersForQuestion(question.getId());
        answersListView.setItems(FXCollections.observableArrayList(answerList));
    }

    private void addAnswer(User user) { //Adds answer for the selected question
        String text = answerInput.getText().trim();
        
        String errorMessage = answerEvaluator.checkAnswer(text);
        
        if (errorMessage != "") {
            messageLabel.setText(errorMessage);
            return;
        }
        answersManager.createAnswer(question, text, user);
        messageLabel.setText("Answer added.");
        answerInput.clear();
        refreshAnswers();
    }

    private void updateAnswer(User user) { //Updates the selected answer
        Answer selectedAnswer = answersListView.getSelectionModel().getSelectedItem();
        if (selectedAnswer == null) {
            messageLabel.setText("No answer selected.");
            return;
        }
        
        String newText = answerInput.getText().trim();
        if (newText.isEmpty()) {
            messageLabel.setText("Cannot set empty answer text.");
            return;
        }
        
        if (selectedAnswer.getAuthor() != user.getUserName()) {
        	messageLabel.setText("You are not the author of this post");
        }
        
        answersManager.updateAnswer(selectedAnswer, newText);
        messageLabel.setText("Answer updated.");
        answerInput.clear();
        refreshAnswers();
    }

    private void deleteAnswer(User user) { //Deletes the selected answer
        Answer selectedAnswer = answersListView.getSelectionModel().getSelectedItem();
        if (selectedAnswer == null) {
            messageLabel.setText("No answer selected.");
            return;
        }
        
        if (selectedAnswer.getAuthor() != user.getUserName()) {
        	messageLabel.setText("You are not the author of this post");
        }
        
        answersManager.deleteAnswer(selectedAnswer, question);
        messageLabel.setText("Answer deleted.");
        refreshAnswers();
    }

    private void likeAnswer() { //Adds a like to the selected answer
        Answer selectedAnswer = answersListView.getSelectionModel().getSelectedItem();
        if (selectedAnswer == null) {
            messageLabel.setText("No answer selected to like.");
            return;
        }
        answersManager.likeAnswer(selectedAnswer);
        messageLabel.setText("Answer liked! Total likes: " + selectedAnswer.getLikes());
        refreshAnswers();
    }

    private void refreshAnswers() { //Refreshes the page
        loadAnswers();
    }
}
