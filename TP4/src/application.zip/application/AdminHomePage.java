package application;

import javafx.application.Application;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class AdminHomePage {

    private Questions questionsManager;  
    private Answers answersManager;      

    private ListView<Question> questionListView;
    private Label messageLabel;
    private TextField questionInput;
    private TextField questionTitle;

  
    public void start(Stage primaryStage, User user) { //Function that displays the page
        try {
            Class.forName("org.h2.Driver");
            Connection connection = DriverManager.getConnection("jdbc:h2:file:./mydb;DB_CLOSE_DELAY=-1;", "sa", "");

            questionsManager = new Questions(connection);
            answersManager = new Answers(connection);

            questionsManager.createTable();
            answersManager.createTable();

            questionsManager.loadAllFromDB();
            answersManager.loadAllFromDB();
            answersManager.linkAnswersToQuestions(questionsManager.getAllQuestions());

        } catch (Exception e) {
            e.printStackTrace();
        }

        primaryStage.setTitle("Discussion Application (Questions)");

        // List of questions
        questionListView = new ListView<>(questionsManager.getAllQuestions());
        questionListView.setCellFactory(param -> new ListCell<>() {
            @Override
            protected void updateItem(Question item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                } else {
                    String resolvedText = item.isResolved() ? " [Resolved]" : "";
                    setText(item.getText() + resolvedText); //+ " (Answers: " + item.getAnswers().size() + ")");
                }
            }
        });

        questionTitle = new TextField();
        questionTitle.setPromptText("Enter a title...");
        
        questionInput = new TextField();
        questionInput.setPromptText("Enter a question...");

        
        Button createBtn = new Button("Create Question");
        createBtn.setOnAction(e -> createQuestion(user));

        Button searchBtn = new Button("Search Question");
        searchBtn.setOnAction(e -> {
			try {
				searchQuestion();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		});
        
        Button updateBtn = new Button("Update Question");
        updateBtn.setOnAction(e -> updateQuestion(user));

        Button deleteBtn = new Button("Delete Question");
        deleteBtn.setOnAction(e -> deleteQuestion(user));

        Button resolvedBtn = new Button("Mark as Resolved");
        resolvedBtn.setOnAction(e -> markQuestionResolved(user));

        
        Button viewAnswersBtn = new Button("View Answers");
        viewAnswersBtn.setOnAction(e -> openAnswersWindow(user));

        HBox questionBtns = new HBox(10, createBtn, updateBtn, deleteBtn, resolvedBtn, viewAnswersBtn, searchBtn);
        questionBtns.setAlignment(Pos.CENTER);

        messageLabel = new Label();

        VBox root = new VBox(15);
        root.setPadding(new Insets(20));
        root.setAlignment(Pos.TOP_CENTER);
        root.setStyle("-fx-background-color: #f0f8ff;");

        VBox questionSection = new VBox(10,
            new Label("Questions"),
            questionListView,
            questionTitle,
            questionInput,
            questionBtns
        );
        questionSection.setMaxWidth(550);

        root.getChildren().addAll(questionSection, messageLabel);

        Scene scene = new Scene(root, 700, 500);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void createQuestion(User user) { //Function to create questions
        String text = questionInput.getText().trim();
        String title = questionTitle.getText().trim();
        
        String errorMessage = questionEvaluator.checkQuestion(title, text);
        
        if (errorMessage != "") {
            messageLabel.setText(errorMessage);
            return;
        }
        questionsManager.createQuestion(text, user.getUserName());
        messageLabel.setText("Question created.");
        questionInput.clear();
        questionListView.refresh();
    }

    private void updateQuestion(User user) { //Function to update questions
        Question selected = questionListView.getSelectionModel().getSelectedItem();
        if (selected == null) {
            messageLabel.setText("No question selected.");
            return;
        }
        String newText = questionInput.getText().trim();
        if (newText.isEmpty()) {
            messageLabel.setText("Cannot set empty question text.");
            return;
        }
        questionsManager.updateQuestion(selected, newText);
        messageLabel.setText("Question updated.");
        questionInput.clear();
        questionListView.refresh();
    }

    private void deleteQuestion(User user) { //Function to delete questions
        Question selected = questionListView.getSelectionModel().getSelectedItem();
        if (selected == null) {
            messageLabel.setText("No question selected.");
            return;
        }
        questionsManager.deleteQuestion(selected);
        messageLabel.setText("Question deleted.");
        questionListView.refresh();
    }

    private void markQuestionResolved(User user) { //Marks questions resolved
        Question selected = questionListView.getSelectionModel().getSelectedItem();
        if (selected == null) {
            messageLabel.setText("No question selected.");
            return;
        }
        questionsManager.markQuestionAsResolved(selected);
        messageLabel.setText("Question marked as resolved.");
        questionListView.refresh();
    }

    private void openAnswersWindow(User user) { //Opens a separate window that shows answers for each question
        Question selected = questionListView.getSelectionModel().getSelectedItem();
        if (selected == null) {
            messageLabel.setText("No question selected to view answers.");
            return;
        }
        
        new AnswersWindow(selected, answersManager, user).show();
        messageLabel.setText("Opened separate window for answers.");
    }
    
    private void searchQuestion() throws SQLException {
    	String text = questionInput.getText().trim();
        if (text.isEmpty()) {
            messageLabel.setText("Cannot search empty question.");
            return;
        }
        ObservableList<Question> similarQuestions = questionsManager.search(text);
        if(similarQuestions.size() == 0) {
        	messageLabel.setText("Question not found.");
        	return;
        }
        questionListView = new ListView<>(similarQuestions);
        questionListView.setCellFactory(param -> new ListCell<>() {
            @Override
            protected void updateItem(Question item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                } else {
                    String resolvedText = item.isResolved() ? " [Resolved]" : "";
                    setText(item.getText() + resolvedText); //+ " (Answers: " + item.getAnswers().size() + ")");
                }
            }
        });
    }
}

    /*
    public static void main(String[] args) {
        launch(args);
    }
}
*/