package application;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import java.sql.*;
//import java.util.ArrayList;
//import java.util.List;

public class Questions {
    private final Connection connection;
    private final ObservableList<Question> allQuestions = FXCollections.observableArrayList();

    public Questions(Connection connection) { //Constructor!
        this.connection = connection;
    }

    public void createTable() throws SQLException { //Creates a table 
        try (Statement st = connection.createStatement()) {
            st.executeUpdate("""
                CREATE TABLE IF NOT EXISTS question (
                  id IDENTITY PRIMARY KEY,
                  text VARCHAR(255) NOT NULL,
                  author VARCHAR(255) NOT NULL,
                  resolved BOOLEAN DEFAULT FALSE
                )
            """);
        }
    }

    public void loadAllFromDB() throws SQLException { //Fetches all the existing questions from the DB
        allQuestions.clear();
        try (Statement st = connection.createStatement();
             ResultSet rs = st.executeQuery("SELECT id, text, author, resolved FROM question")) {
            while (rs.next()) {
                long id = rs.getLong("id");
                String txt = rs.getString("text");
                boolean res = rs.getBoolean("resolved");
                String author = rs.getString("author");
                
                Question q = new Question(id, txt, author);
                q.setResolved(res);
                allQuestions.add(q);
            }
        }
    }

    public void createQuestion(String text, String author) { //Creates a new question
        try {
            long newId = insertQuestionDB(text, author);
            Question q = new Question(newId, text, author);
            allQuestions.add(q);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateQuestion(Question q, String newText) { //Updates the selected question
        try {
            String sql = "UPDATE question SET text=? WHERE id=?";
            try (PreparedStatement ps = connection.prepareStatement(sql)) {
                ps.setString(1, newText);
                ps.setLong(2, q.getId());
                ps.executeUpdate();
            }
            q.setText(newText);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void markQuestionAsResolved(Question q) { //Marks the selected question as resolved
        try {
            String sql = "UPDATE question SET resolved = ? WHERE id = ?";
            try (PreparedStatement ps = connection.prepareStatement(sql)) {
                ps.setBoolean(1, true);
                ps.setLong(2, q.getId());
                ps.executeUpdate();
            }
            q.setResolved(true);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteQuestion(Question q) { //Deletes the selected question
        try {
            String sql = "DELETE FROM question WHERE id=?";
            try (PreparedStatement ps = connection.prepareStatement(sql)) {
                ps.setLong(1, q.getId());
                ps.executeUpdate();
            }
            allQuestions.remove(q);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public ObservableList<Question> getAllQuestions() { //Fills the observable list
        return allQuestions;
    }

    //Unused
    /*
    public List<Question> search(String partial) {
        String lower = partial.toLowerCase();
        List<Question> subset = new ArrayList<>();
        for (Question q : allQuestions) {
            if (q.getText().toLowerCase().contains(lower)) {
                subset.add(q);
            }
        }
        return subset;
    }
    */
    
    public ObservableList<Question> search(String text) throws SQLException{
    	ObservableList<Question> specificQuestions = FXCollections.observableArrayList();
    	String query = "SELECT id, text, author, resolved FROM question where text like ?";
    	PreparedStatement st = connection.prepareStatement(query);
		st.setString(1, text);
    	try (ResultSet rs = st.executeQuery(query)) {
               while (rs.next()) {
                   long id = rs.getLong("id");
                   String txt = rs.getString("text");
                   boolean res = rs.getBoolean("resolved");
                   String author = rs.getString("author");

                   Question q = new Question(id, txt, author);
                   q.setResolved(res);
                   allQuestions.add(q);
               }
        }
    	return specificQuestions;
    }
    

    private long insertQuestionDB(String text, String author) throws SQLException { //Inserts a new question into the DB
        String sql = "INSERT INTO question (text, author) VALUES (?, ?)";
        try (PreparedStatement ps = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, text);
            ps.setString(2, author);
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    return rs.getLong(1);
                }
            }
        }
        throw new SQLException("Failed to insert question.");
    }
}
